package com.example.pdf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfGenerationApplication {
    public static void main(String[] args) {
        SpringApplication.run(PdfGenerationApplication.class, args);
    }
}
